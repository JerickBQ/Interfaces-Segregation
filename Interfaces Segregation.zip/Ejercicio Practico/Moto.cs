// La clase "Moto" va a hacer uso de 2 interfaces (Ivelocidad,IArquitecura)
// Esta clase necesita solo estas 2 interfaces ya que segun en su logica no existe una propiedad que 
// que tenga una radio o el uso de CD y por lo tanto menos un metodo con esas propiedades 
// Asi no habria un metodo que quedaria vacio o sin ningun sentido en el programa.
class Moto:IVelocidad,IArquitectura{
public int Motor {get;set;}
public int Cambios {get;set;}
public int Acelera {get;set;}
public int Frena {get;set;}
public int Tanque {get;set;}
public int Llantas {get;set;}
public int Asientos {get;set;}
public void EncenderMotor(){
    Console.WriteLine("La moto tiene un Motor lo cual le permite encender");
    
}
public void CambiarMarcha(){
    Console.WriteLine("La moto puede hacer cambios ");

}
public void AcelerarVelocidad(){
    Console.WriteLine("La moto puede aumentar la velocidad mediante la acelacion");

}
public void FrenarVelocidad(){
    Console.WriteLine("La moto contiene frenos por lo que le permite detenerse ");
}
public void DeGasolina(){
    Console.WriteLine("La moto tiene un tanque de gasolina que se puede rellenar");
}
public void DespLlantas(){
    Console.WriteLine("La moto se desplaza mediante llantas");
}
public void ContAsientos(){
    Console.WriteLine("La moto tiene asientos donde van los pasajeros");
}

}