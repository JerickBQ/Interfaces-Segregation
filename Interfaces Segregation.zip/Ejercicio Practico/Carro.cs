// La clase "Carro" va a hacer uso de 3 interfaces (Ivelocidad,IAudio,IArquitecura)
// Esta clase necesita todas estas interfaces ya que segun en su logica existen por lo que 
// no habria un metodo que quedaria vacio o sin ningun sentido en el programa.
class Carro:IVelocidad,IAudio,IArquitectura{
public int Motor {get;set;}
public int Cambios {get;set;}
public int Acelera {get;set;}
public int Frena {get;set;}
public int Radio {get;set;}
public int Cd {get;set;}
 public int Tanque {get;set;}
public int Llantas {get;set;}
public int Asientos {get;set;}
public void EncenderMotor(){
    Console.WriteLine("El carro tiene un Motor lo cual le permite encender");
    
}
public void CambiarMarcha(){
    Console.WriteLine("El carro puede hacer cambios ");

}
public void AcelerarVelocidad(){
    Console.WriteLine("El carro puede aumentar la velocidad mediante la acelacion");

}
public void FrenarVelocidad(){
    Console.WriteLine("El carro contiene frenos por lo que le permite detenerse ");
}
public void EscucharRadio(){
    Console.WriteLine("El carro contiene Radio por lo que puede escucharla");
}
public void EscucharCd(){
    Console.WriteLine("El carro puede escuchar audios por CD");
}
public void DeGasolina(){
    Console.WriteLine("El carro tiene un tanque de gasolina que se puede rellenar");
}
public void DespLlantas(){
    Console.WriteLine("El carro se desplaza mediante llantas");
}
public void ContAsientos(){
    Console.WriteLine("El carro tiene asientos donde van los pasajeros");
}
}
