// Se presenta una interface llamada "Ivelocidad" que contiene los constructores (Motor, Cambios, Acelera, Frena)
// y sus metodos (EncerderMotor, CambiarMarcha, AcelerarVelocidad, FrenarVelocidad)
// se ha agrupado todas las relaciones que puede a ver en la velocidad de un vehiculo en esta interface
// para despues relacionarla con la clase que vaya a hacer uso de esta interface.
interface IVelocidad{
public int Motor {get;set;}
public int Cambios {get;set;}
public int Acelera {get;set;}
public int Frena {get;set;}
public void EncenderMotor();
public void CambiarMarcha();
public void AcelerarVelocidad();
public void FrenarVelocidad();

}
