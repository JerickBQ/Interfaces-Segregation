﻿// NOTA
// Este ejercicio representa el uso del patron de diseño "Interfaces Segregation" con el objetivo
// de mostrar su finalidad en e codigo para que tenga cohesion y acoplamiento y tener un codigo 
// con sentido y coherencia.
// Este Patron de Diseño nos muestra el uso de mas de una interfaces sustituyendo asi la multiherencia que 
// es usada en otros Lenguajes de Programacion y al contrario de C# no es adecuado usar.
// La segregacion se hace cuando se presentan metodos que no vayas a necesitar en todas las clases
// de esta manera para tener un codigo con un funcionamiento mas limpio y con sentido
// se crea mas interfaces agrupando las propiedades y metodos para que las clases hagan uso unicamente 
// de las que necesiten y no quede ningun metodo vacio.
// MAIN
// Se muestran los metodos y gracias a las interfaces estos son mostrados en la clase correspodiente. 
class Program{
static void Main (string[] args){
Carro c1 = new Carro();
c1.EncenderMotor();
c1.CambiarMarcha();
c1.AcelerarVelocidad();
c1.FrenarVelocidad();
c1.EscucharRadio();
c1.EscucharCd();
c1.DeGasolina();
c1.DespLlantas();
c1.ContAsientos();
Moto c2 = new Moto();
c2.EncenderMotor();
c2.CambiarMarcha();
c2.AcelerarVelocidad();
c2.FrenarVelocidad();
c2.DeGasolina();
c2.DespLlantas();
c2.ContAsientos();
}
}