// Se presenta una interface llamada "IAudio" que contiene los constructores (Radio, Cd)
// y sus metodos (EscucharRadio, EscucharCd)
//Se ha agrupado todas las relaciones que puede a ver en el audio de un vehiculo en esta interface
// para despues relacionarla con la clase que vaya a hacer uso de esta interface.
interface IAudio{
public int Radio {get;set;}
public int Cd {get;set;}
public void EscucharRadio();
public void EscucharCd();

}