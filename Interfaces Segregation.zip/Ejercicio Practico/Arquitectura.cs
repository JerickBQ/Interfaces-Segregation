// Se presenta una interface llamada "IArquitecura" que contiene los constructores (Tanque, Llantas, Asientos)
// y sus metodos (DeGasolina, DespLlantas, ContAsientos)
//Se ha agrupado todas las relaciones que puede a ver en la arquitectura fisica de un vehiculo en esta interface
// para despues relacionarla con la clase que vaya a hacer uso de esta interface.
interface IArquitectura{
public int Tanque {get;set;}
public int Llantas {get;set;}
public int Asientos {get;set;}
public void DeGasolina();
public void DespLlantas();
public void ContAsientos();

}